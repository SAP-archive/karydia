// Copyright 2017 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// Package dependencies provides functions for determining the set of ast.Refs that AST
// elements depend on.
package dependencies
