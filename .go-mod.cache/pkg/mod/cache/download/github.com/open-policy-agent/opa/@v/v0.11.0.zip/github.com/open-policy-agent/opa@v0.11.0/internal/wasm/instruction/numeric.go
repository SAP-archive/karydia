// Copyright 2018 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package instruction

import (
	"github.com/open-policy-agent/opa/internal/wasm/opcode"
)

// I32Const represents the WASM i32.const instruction.
type I32Const struct {
	Value int32
}

// Op returns the opcode of the instruction.
func (I32Const) Op() opcode.Opcode {
	return opcode.I32Const
}

// ImmediateArgs returns the i32 value to push onto the stack.
func (i I32Const) ImmediateArgs() []interface{} {
	return []interface{}{i.Value}
}

// I64Const represents the WASM i64.const instruction.
type I64Const struct {
	Value int64
}

// Op returns the opcode of the instruction.
func (I64Const) Op() opcode.Opcode {
	return opcode.I64Const
}

// ImmediateArgs returns the i64 value to push onto the stack.
func (i I64Const) ImmediateArgs() []interface{} {
	return []interface{}{i.Value}
}

// I32Eqz represents the WASM i32.eqz instruction.
type I32Eqz struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32Eqz) Op() opcode.Opcode {
	return opcode.I32Eqz
}

// I32Ne represents the WASM i32.ne instruction.
type I32Ne struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32Ne) Op() opcode.Opcode {
	return opcode.I32Ne
}

// I32GtS represents the WASM i32.gt_s instruction.
type I32GtS struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32GtS) Op() opcode.Opcode {
	return opcode.I32GtS
}

// I32GeS represents the WASM i32.ge_s instruction.
type I32GeS struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32GeS) Op() opcode.Opcode {
	return opcode.I32GeS
}

// I32LtS represents the WASM i32.lt_s instruction.
type I32LtS struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32LtS) Op() opcode.Opcode {
	return opcode.I32LtS
}

// I32LeS represents the WASM i32.le_s instruction.
type I32LeS struct {
	NoImmediateArgs
}

// Op returns the opcode of the instruction.
func (I32LeS) Op() opcode.Opcode {
	return opcode.I32LeS
}
