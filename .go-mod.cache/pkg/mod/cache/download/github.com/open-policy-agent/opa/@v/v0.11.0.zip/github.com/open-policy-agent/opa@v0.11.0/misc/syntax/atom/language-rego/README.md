# language-rego package

Syntax highlighting for Rego, the open-policy-agent (OPA) policy language

