# rego README

This is an Atom.io package for syntax highlighting Rego, the open-policy-agent (OPA) policy language.

## Installation

To install, copy the `language-rego` folder to the `~/.atom/packages` folder.

## Auto-generation

You can regenerate this folder from the `../textmate/Rego.tmLanguage` file by following
these [instructions](http://flight-manual.atom.io/hacking-atom/sections/converting-from-textmate/).  
