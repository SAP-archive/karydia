#!/bin/bash

kubectl -n qa apply -f ingress-bad.yaml