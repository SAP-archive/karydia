package dirio

type SomeType struct {
	X int
}
