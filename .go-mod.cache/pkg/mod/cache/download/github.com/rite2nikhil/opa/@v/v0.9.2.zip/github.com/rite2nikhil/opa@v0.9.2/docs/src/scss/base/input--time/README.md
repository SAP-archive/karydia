Basic time input for a form.
