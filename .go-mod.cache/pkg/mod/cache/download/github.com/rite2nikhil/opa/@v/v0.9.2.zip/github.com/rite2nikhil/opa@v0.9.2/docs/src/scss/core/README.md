# Core

Core items are items that are shared universally across the pattern library. Examples include Sass colors and typography settings and JavaScript polyfills.