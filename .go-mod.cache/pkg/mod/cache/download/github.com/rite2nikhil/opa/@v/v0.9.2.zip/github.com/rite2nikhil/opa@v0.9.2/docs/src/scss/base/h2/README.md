Heading Level 2, `<h2>`, is a second level heading within an associated section
