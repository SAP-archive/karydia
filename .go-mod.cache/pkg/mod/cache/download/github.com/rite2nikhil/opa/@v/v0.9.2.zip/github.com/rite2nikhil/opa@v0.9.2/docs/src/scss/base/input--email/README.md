Basic email input for a form.
