Basic date input for a form.
