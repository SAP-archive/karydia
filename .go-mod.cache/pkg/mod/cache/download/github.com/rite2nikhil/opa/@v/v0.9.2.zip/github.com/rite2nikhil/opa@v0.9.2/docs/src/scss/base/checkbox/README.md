A single check box, `<input type=["checkbox"]>`, is an individual form option where multiple choices may be selected, including, but not requiring this particular element.
