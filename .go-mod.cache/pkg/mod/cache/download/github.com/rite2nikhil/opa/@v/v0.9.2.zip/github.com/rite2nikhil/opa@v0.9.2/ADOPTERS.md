This is a list of known adopters of OPA. Some have gone into production and
others are at various stages of testing.

* [Netflix](https://www.netflix.com)
* [Chef](https://www.chef.io/)
* [Medallia](https://www.medallia.com/)
* [SolarWinds](https://www.solarwinds.com/) via [Lee Calcote](https://github.com/leecalcote)
* [Cisco](https://www.cisco.com/)
* [Cloudflare](https://www.cloudflare.com/)
* [Pinterest](https://www.pinterest.com/)
* [State Street Corporation](http://www.statestreet.com/)

If you have adopted OPA and would like to be included in this list, feel free to
submit a PR.
