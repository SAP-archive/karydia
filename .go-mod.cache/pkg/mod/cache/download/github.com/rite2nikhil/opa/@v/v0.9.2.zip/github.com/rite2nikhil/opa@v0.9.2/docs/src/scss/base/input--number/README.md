Basic number input for a form.
