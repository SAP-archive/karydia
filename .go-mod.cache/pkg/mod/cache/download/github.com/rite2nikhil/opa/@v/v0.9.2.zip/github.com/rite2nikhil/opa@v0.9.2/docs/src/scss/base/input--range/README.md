Basic range input for a form.
