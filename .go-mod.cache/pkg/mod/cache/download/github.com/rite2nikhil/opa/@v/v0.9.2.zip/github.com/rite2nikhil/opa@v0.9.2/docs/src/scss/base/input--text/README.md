Basic text input for a form.
