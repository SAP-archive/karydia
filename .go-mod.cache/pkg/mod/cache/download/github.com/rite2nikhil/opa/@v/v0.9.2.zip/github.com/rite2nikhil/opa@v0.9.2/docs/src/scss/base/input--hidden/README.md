Basic hidden input for a form.
