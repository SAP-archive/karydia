A blockquote, `<blockquote>`, indicates that the enclosed text is an extended quotation
