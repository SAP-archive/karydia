Basic telephone input type for a form. These can read for specific regex phone patterns, or by default, accept a numeric-only input.
