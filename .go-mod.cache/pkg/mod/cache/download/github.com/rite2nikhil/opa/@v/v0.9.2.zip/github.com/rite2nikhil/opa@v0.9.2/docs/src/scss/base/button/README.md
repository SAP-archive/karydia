Button, `<button>`, is an element which may serve as a trigger to an action. Submit buttons are linked to forms and push the data from the form to the server. Reset buttons will clear any inputs.
