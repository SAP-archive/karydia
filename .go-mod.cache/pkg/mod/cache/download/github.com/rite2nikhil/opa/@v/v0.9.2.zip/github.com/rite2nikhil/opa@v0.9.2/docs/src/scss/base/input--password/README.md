Basic password input for a form.
