Basic file input for a form.
