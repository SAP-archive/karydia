Unordered List, `<ul>`, is the base styling for a listing of items whose order is not relevant to their display
