The `<body>` tag defines the body of the document, which contains all of its content.
