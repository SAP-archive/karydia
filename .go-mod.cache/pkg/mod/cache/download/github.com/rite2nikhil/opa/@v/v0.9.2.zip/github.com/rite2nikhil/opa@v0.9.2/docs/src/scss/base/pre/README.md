Pre formatted text, `<pre>`, is an example of text in which the whitespace is preserved. It is most often used with a nested `<code>` tag to display code blocks.
