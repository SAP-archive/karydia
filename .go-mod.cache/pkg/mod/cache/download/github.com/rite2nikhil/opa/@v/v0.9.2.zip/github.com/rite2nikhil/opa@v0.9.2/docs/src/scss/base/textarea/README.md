A flexible and configurable area for a long-form text input.
