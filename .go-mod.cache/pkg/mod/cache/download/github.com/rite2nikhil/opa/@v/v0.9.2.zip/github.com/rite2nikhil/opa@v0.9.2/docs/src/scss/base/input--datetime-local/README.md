Basic datetime-local input for a form.
