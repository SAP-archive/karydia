Anchor link, `<a>`, is the base styling for a link
