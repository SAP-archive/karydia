Code text, `<code>`, is an example of computer code within text
