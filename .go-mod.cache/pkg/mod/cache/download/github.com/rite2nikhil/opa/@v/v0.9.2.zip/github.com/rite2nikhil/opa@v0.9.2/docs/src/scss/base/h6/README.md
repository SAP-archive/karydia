Heading Level 6, `<h6>`, is a sixth level heading within an associated section
