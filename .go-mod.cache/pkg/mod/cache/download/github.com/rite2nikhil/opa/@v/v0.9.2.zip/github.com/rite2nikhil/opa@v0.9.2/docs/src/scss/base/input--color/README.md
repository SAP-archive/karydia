Basic color input for a form.
