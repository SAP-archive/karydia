Basic search input for a form.
