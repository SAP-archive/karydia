A flexible and configurable way of selecting an individual item from a list. Lists should be kept as short as possible.
