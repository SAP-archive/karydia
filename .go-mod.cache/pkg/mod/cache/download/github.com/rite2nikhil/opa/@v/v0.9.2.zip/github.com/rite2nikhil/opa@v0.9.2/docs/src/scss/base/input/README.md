Basic input for a form.
