Important text, `<strong>`, defines an important phrase tag
