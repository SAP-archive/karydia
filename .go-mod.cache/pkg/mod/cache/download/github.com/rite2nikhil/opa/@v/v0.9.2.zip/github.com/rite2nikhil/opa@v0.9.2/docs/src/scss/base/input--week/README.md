Basic week input for a form.
