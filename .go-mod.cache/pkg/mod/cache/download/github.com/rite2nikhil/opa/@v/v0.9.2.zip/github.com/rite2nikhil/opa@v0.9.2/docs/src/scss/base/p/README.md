The paragraph element, `<p>`, represents a longer section of text. Authors traditionally divide their thoughts and arguments into sequences of paragraphs.
