Ordered List, `<ol>`, is the base styling for a listing of items whose order is relevant to their display
