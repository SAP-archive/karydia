Emphasized text, `<em>`, is the emphasized phrase tag
