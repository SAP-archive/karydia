Basic month input for a form.
