Basic url input for a form.
