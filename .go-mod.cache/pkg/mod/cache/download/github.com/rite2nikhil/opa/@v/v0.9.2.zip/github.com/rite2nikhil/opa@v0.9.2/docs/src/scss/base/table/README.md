Table, `<table>`, and the related `<tr>`, `<th>`, `<td>`, `<thead>`, and `<tbody>` tags, are used to display tabular data
