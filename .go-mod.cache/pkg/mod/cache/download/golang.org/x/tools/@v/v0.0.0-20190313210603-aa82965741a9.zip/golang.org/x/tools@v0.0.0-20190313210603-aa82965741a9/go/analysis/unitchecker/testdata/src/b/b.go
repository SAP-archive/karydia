package b

import "a"

func _() {
	a.MyFunc123()
	MyFunc123()
}

func MyFunc123() {}
